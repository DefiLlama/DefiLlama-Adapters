const { uniTvlExport } = require('../helper/unknownTokens');

module.exports.hallmarks=[[1705708800,"Rug Pull"]];
module.exports = uniTvlExport('zkfair', '0x3582Ccde3F786229CE6Dbd88c5aDb86bF64DAA31')
module.exports.deadFrom = '2024-01-20';
