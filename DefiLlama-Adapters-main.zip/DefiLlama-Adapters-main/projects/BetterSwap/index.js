const { uniTvlExports } = require('../helper/unknownTokens')
module.exports = uniTvlExports({
  'vechain': '0x5970dcbebac33e75eff315c675f1d2654f7bf1f5'
})