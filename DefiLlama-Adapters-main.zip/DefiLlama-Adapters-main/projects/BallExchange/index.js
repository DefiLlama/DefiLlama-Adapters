const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('shibarium', '0x6d17c4d4524de46e33a09deb37ad6e7e87780137', { })
