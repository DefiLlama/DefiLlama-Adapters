const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('xlayer', '0x40E9fC0A18ccfDc87C19A1bA5b7F84FC51879600', {  hasStablePools: true })
