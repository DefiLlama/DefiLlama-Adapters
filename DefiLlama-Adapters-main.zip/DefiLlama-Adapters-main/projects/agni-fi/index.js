const { uniV3Export } = require("../helper/uniswapV3");

module.exports = uniV3Export({
  mantle: { factory: "0x25780dc8Fc3cfBD75F33bFDAB65e969b603b2035", fromBlock: 35714, },
});