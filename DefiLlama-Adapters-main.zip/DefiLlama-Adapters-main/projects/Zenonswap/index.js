const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('degen', '0x97B162AD1443737B0500A5E726344D608eB9e255')