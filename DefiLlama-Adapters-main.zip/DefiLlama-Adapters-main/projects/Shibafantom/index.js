const { uniTvlExports } = require('../helper/unknownTokens')
module.exports = uniTvlExports({
  'fantom': '0xeAcC845E4db0aB59A326513347a37ed4E999aBD8'
})