const { uniTvlExport } = require("../helper/unknownTokens");
const chain = "bittorrent";
const factory = "0xea34610f4373c8d75ed1810A6096197F297F2786"; // v2 factory address

module.exports = uniTvlExport(chain, factory);
