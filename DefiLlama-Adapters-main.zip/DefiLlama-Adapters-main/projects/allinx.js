module.exports = {
  methodology: 'Project is abandoned',
  bsc: {
    tvl: () => 0
  },
  deadFrom: 1680328420,
}
