const { uniTvlExports } = require('../helper/unknownTokens')
module.exports = uniTvlExports({
  'fantom': '0xD9473A05b2edf4f614593bA5D1dBd3021d8e0Ebe'
})