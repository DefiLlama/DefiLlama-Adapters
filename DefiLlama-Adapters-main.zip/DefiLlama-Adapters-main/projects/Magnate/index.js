module.exports = {
  base: {
    tvl:() => ({}),
    staking:() => ({}),
    pool2:() => ({}),
    borrowed:() => ({}),
  },
  // hallmarks: [
  //   ['2023-08-25', 'Project Rugged'],
  // ],
  deadFrom: '2023-08-25'
};
