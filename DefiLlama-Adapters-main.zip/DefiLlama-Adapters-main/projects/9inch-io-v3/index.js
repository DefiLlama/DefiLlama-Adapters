const { uniV3Export } = require('../helper/uniswapV3')

module.exports = uniV3Export({ pulse: { factory: '0xCfd33C867C9F031AadfF7939Cb8086Ee5ae88c41', fromBlock: 20357155, } })