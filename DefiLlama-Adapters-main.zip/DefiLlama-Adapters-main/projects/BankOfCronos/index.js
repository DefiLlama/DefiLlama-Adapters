module.exports = {
  cronos: {
    tvl: () => 0
  },
  methodology:
    "CDP collateral value + treasury mv",
};

