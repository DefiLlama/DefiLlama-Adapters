const { uniV3Export } = require("../helper/uniswapV3");

module.exports = uniV3Export({
  morph: {
    factory: "0x1be404c921ef85537233ef2be251a27583072861",
    fromBlock: 166014,
    isAlgebra: true,
  },
});