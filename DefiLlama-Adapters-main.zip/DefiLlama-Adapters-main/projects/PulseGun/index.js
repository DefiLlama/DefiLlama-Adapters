const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('pulse', '0x5c92d17f52987DED8D2c0Fa0d5fbfcD68A09B074')