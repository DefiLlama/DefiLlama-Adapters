module.exports = {
    avax: {
      tvl: () => ({}),
      staking: () => ({}),
    },
}
module.exports.deadFrom = '2022-03-01'