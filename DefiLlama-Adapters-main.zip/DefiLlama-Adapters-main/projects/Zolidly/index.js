module.exports = {
  misrepresentedTokens: true,
  hallmarks: [
    [1684713600, "Rug Pull"]
  ],
  deadFrom: '2023-05-22',
  era: {
    tvl: () => ({}),
  },
  methodology: "Counts liquidity in pools",
};