module.exports = {
  hallmarks: [
    [1680307200, "Rug Pull"]
  ],
  deadFrom: '2023-04-01',
  misrepresentedTokens: true,
  loop: {
    tvl: () => ({}),
  }
}