const { uniV3Export } = require("../helper/uniswapV3");

module.exports = uniV3Export({ blast: { factory: "0x9792FaeA53Af241bCE57C7C8D6622d5DaAD0D4Fc", fromBlock: 693561, }, })

