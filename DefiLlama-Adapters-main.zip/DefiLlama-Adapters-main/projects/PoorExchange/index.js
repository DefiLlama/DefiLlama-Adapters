const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('arbitrum', '0x9fA0988D9e4b6362e0aaA02D1A09196a78c177e1')
