const { compoundExports2 } = require('../helper/compound');

module.exports = {
    blast: compoundExports2({
        comptroller: '0xe20cE0Db739e4B6Afa9989c87bE7C8C25cbeB5Ea',
        cether: '0x29e15766d6b203C35c2D51AAEc4Cf964129Af088',
    }),
}; 
module.exports.deadFrom='2024-04-03',
module.exports.blast.borrowed = () => ({}) // bad debt
