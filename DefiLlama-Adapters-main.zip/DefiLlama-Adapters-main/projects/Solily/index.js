

module.exports = {
  hallmarks: [
    [1655251200, "Rug Pull"]
  ],
  timetravel: false, 
  deadFrom: 1655251200,
  solana: {
    tvl: () => 0,
  },
  methodology: 'website unreachable, twitter deleted',
}
