module.exports = {
  methodology: "Pool2 deposits consist of 2DOGE/FTM and 2SDOGE/FTM LP tokens deposits while the staking TVL consists of the 2SDOGES tokens locked within the Masonry contract(0xe8EA0828FF7BF03c868a2370b83Bc06F50d4eEd9).",
  fantom: {
    tvl: () => ({}),
    staking: () => ({}),
    pool2: () => ({}),
  },
  hallmarks: [
    [1646179200, "Rug Pull"]
  ],
  deadFrom: 1646179200
};
