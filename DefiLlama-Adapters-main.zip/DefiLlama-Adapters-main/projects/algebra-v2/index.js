const { uniV3Export } = require("../helper/uniswapV3");

module.exports = uniV3Export({
  avax: { factory: "0xa2A92Bb449CCa49b810C84c0efC36a88431655f2", fromBlock: 31662680, isAlgebra: true, },
});
