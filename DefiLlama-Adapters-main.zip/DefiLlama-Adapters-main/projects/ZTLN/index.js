module.exports = {
  timetravel: false,
  misrepresentedTokens: true,
  methodology: "The value in RWA held by the protocol",
  hallmarks: [
    ['2025-01-13', 'ZTLN is deprecated'],
  ],
  deadFrom: "2025-01-13",
  ethereum: {
    tvl: () => ({}),
  },
};