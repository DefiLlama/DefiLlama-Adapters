module.exports.hallmarks = [[1703808000, "Rug Pull"]]
module.exports.beam = { tvl: () => ({}) }
module.exports.deadFrom = 1703808000