const { uniTvlExports } = require('../helper/unknownTokens')
module.exports = uniTvlExports({
  'sonic': '0x05c1be79d3aC21Cc4B727eeD58C9B2fF757F5663'
}, { hasStablePools: true, })

