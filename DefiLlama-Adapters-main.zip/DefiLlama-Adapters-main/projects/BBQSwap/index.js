const { uniTvlExport } = require('../helper/unknownTokens')

module.exports = uniTvlExport('ham', '0x7304e5751973113fA7c4FFf677871B926258f27e')
