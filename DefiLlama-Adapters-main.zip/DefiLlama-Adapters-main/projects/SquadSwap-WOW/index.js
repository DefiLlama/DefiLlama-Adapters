const { uniV3Export } = require('../helper/uniswapV3')

module.exports = uniV3Export({
    bsc: { factory: '0x10d8612D9D8269e322AB551C18a307cB4D6BC07B', fromBlock: 46190543 }
})
