const { gmxExports } = require('../helper/gmx')

module.exports = {
  scroll: {
    tvl: gmxExports({ vault: '0x2C145157e59CfB69a4607643D178B015E6A3004a' })
  },
};
