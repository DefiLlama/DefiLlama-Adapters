
module.exports={
    methodology: "Data is retrieved from the api at https://amm-api.adax.pro/",
    timetravel: false, // but there's historical data, this can be changed!
    cardano: {
        tvl: () => ({}),
    },
    hallmarks: [
      ['2023-08-29', 'Website offline! Rug pull?'],
    ],
    deadFrom: '2023-08-29'
}