const { joeV2Export } = require('../helper/traderJoeV2')

module.exports = joeV2Export({
  fantom:	'0x8597dB3ba8dE6BAAdEDa8cBa4dAC653E24a0e57B',
  arbitrum: '0x8597dB3ba8dE6BAAdEDa8cBa4dAC653E24a0e57B',
  base:		'0x8597dB3ba8dE6BAAdEDa8cBa4dAC653E24a0e57B'
})