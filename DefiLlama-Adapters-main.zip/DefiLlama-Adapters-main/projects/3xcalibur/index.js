
const { uniTvlExports } = require('../helper/unknownTokens')
module.exports = uniTvlExports({
  'arbitrum': '0xD158bd9E8b6efd3ca76830B66715Aa2b7Bad2218'
}, { hasStablePools: true, hallmarks: [[1668038400, "Emissions started"]], })